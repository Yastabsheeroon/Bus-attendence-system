import { Student, Bus } from './types';

export const MOCK_STUDENTS: Student[] = [
  { id: 'S001', name: 'Emma Thompson', grade: '5A', avatar: 'https://picsum.photos/100/100?random=1', parentPhone: '+1-555-0101', busId: 'B-101', stopName: 'Maple Ave' },
  { id: 'S002', name: 'Liam Johnson', grade: '4B', avatar: 'https://picsum.photos/100/100?random=2', parentPhone: '+1-555-0102', busId: 'B-101', stopName: 'Oak St' },
  { id: 'S003', name: 'Olivia Williams', grade: '6A', avatar: 'https://picsum.photos/100/100?random=3', parentPhone: '+1-555-0103', busId: 'B-102', stopName: 'Pine Rd' },
  { id: 'S004', name: 'Noah Brown', grade: '3C', avatar: 'https://picsum.photos/100/100?random=4', parentPhone: '+1-555-0104', busId: 'B-101', stopName: 'Maple Ave' },
  { id: 'S005', name: 'Ava Jones', grade: '5B', avatar: 'https://picsum.photos/100/100?random=5', parentPhone: '+1-555-0105', busId: 'B-103', stopName: 'Cedar Ln' },
  { id: 'S006', name: 'Elijah Garcia', grade: '4A', avatar: 'https://picsum.photos/100/100?random=6', parentPhone: '+1-555-0106', busId: 'B-102', stopName: 'Pine Rd' },
  { id: 'S007', name: 'Mia Miller', grade: '2A', avatar: 'https://picsum.photos/100/100?random=7', parentPhone: '+1-555-0107', busId: 'B-101', stopName: 'Oak St' },
  { id: 'S008', name: 'Lucas Davis', grade: '6B', avatar: 'https://picsum.photos/100/100?random=8', parentPhone: '+1-555-0108', busId: 'B-103', stopName: 'Elm St' },
  { id: 'S009', name: 'Isabella Rodriguez', grade: '3B', avatar: 'https://picsum.photos/100/100?random=9', parentPhone: '+1-555-0109', busId: 'B-102', stopName: 'Birch Dr' },
  { id: 'S010', name: 'Mason Martinez', grade: '5A', avatar: 'https://picsum.photos/100/100?random=10', parentPhone: '+1-555-0110', busId: 'B-101', stopName: 'Maple Ave' },
  { id: 'S011', name: 'Sophia Hernandez', grade: '1A', avatar: 'https://picsum.photos/100/100?random=11', parentPhone: '+1-555-0111', busId: 'B-103', stopName: 'Cedar Ln' },
  { id: 'S012', name: 'James Lopez', grade: '6C', avatar: 'https://picsum.photos/100/100?random=12', parentPhone: '+1-555-0112', busId: 'B-102', stopName: 'Pine Rd' },
];

export const MOCK_BUSES: Bus[] = [
  { 
    id: 'B-101', 
    plateNumber: 'SB-2023-A', 
    driverName: 'John Smith', 
    status: 'RUNNING', 
    location: { lat: 34.0522, lng: -118.2437 }, 
    speed: 45, 
    nextStop: 'Maple Ave', 
    eta: '5 min',
    occupancy: 12,
    capacity: 40,
    routeId: 'R-NORTH' 
  },
  { 
    id: 'B-102', 
    plateNumber: 'SB-2023-B', 
    driverName: 'Sarah Conner', 
    status: 'DELAYED', 
    location: { lat: 34.0407, lng: -118.2468 }, 
    speed: 15, 
    nextStop: 'Pine Rd', 
    eta: '12 min',
    occupancy: 28,
    capacity: 40,
    routeId: 'R-EAST'
  },
  { 
    id: 'B-103', 
    plateNumber: 'SB-2023-C', 
    driverName: 'Mike Ross', 
    status: 'RUNNING', 
    location: { lat: 34.0550, lng: -118.2500 }, 
    speed: 38, 
    nextStop: 'Cedar Ln', 
    eta: '2 min',
    occupancy: 5,
    capacity: 40,
    routeId: 'R-SOUTH'
  }
];

export const SYSTEM_METRICS_BASE = {
  accuracy: 99.8,
  frr: 0.15,
  far: 0.001
};

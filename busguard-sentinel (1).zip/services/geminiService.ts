import { GoogleGenAI } from "@google/genai";
import { DailyStats, Student, Alert } from "../types";

const getClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) return null;
  return new GoogleGenAI({ apiKey });
};

export const generateSafetyReport = async (
  stats: DailyStats,
  missingStudents: Student[],
  alerts: Alert[]
): Promise<string> => {
  const ai = getClient();
  if (!ai) {
    return "API Key not found. Please configure the environment variable to enable AI reporting.";
  }

  const prompt = `
    You are the Chief Safety Officer for a highly advanced School Bus Transport System.
    
    Task: Analyze the daily transport data and write a concise, professional executive summary for the School Principal.
    
    ## Daily Statistics
    - **Total Registered:** ${stats.totalStudents}
    - **Morning Boarding:** ${stats.amCount}
    - **Return Boarding:** ${stats.pmCount}
    - **MISSING RETURNS:** ${stats.missingReturnCount} (Students who arrived in the AM but did not board the return bus)
    
    ## Fleet Status
    - Active: ${stats.fleetStatus?.running || 0}
    - Delayed: ${stats.fleetStatus?.delayed || 0}
    - Breakdowns: ${stats.fleetStatus?.breakdown || 0}

    ## Critical Missing Students
    ${missingStudents.length > 0 
      ? missingStudents.map(s => `- ${s.name} (Grade ${s.grade}, Bus ${s.busId})`).join('\n') 
      : "None. All morning students accounted for."}
    
    ## Recent System Alerts
    ${alerts.length > 0 ? alerts.slice(0, 5).map(a => `- [${a.severity}] ${a.message}`).join('\n') : "No critical system alerts."}
    
    ## System Performance
    - Identification Accuracy: ${stats.systemHealth.accuracy}%
    
    ## Output Requirements
    1. **Status Header**: Start with "STATUS: GREEN" (All clear), "STATUS: YELLOW" (Minor warnings), or "STATUS: RED" (Missing students).
    2. **Executive Summary**: 2-3 sentences summarizing the day.
    3. **Action Items**: Bullet points of immediate actions required.
    4. **Tone**: Professional, urgent (if red), reassuring (if green).
    5. **Formatting**: Use Markdown (bolding, lists).
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
    });
    return response.text || "No report generated.";
  } catch (error) {
    console.error("Error generating report:", error);
    return "Failed to generate safety report. Please check API connection.";
  }
};

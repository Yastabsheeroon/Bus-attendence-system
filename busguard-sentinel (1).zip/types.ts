export interface Student {
  id: string;
  name: string;
  grade: string;
  avatar: string;
  parentPhone: string;
  busId: string;
  stopName: string;
}

export enum BusSession {
  MORNING = 'MORNING',
  AFTERNOON = 'AFTERNOON',
}

export interface AttendanceRecord {
  studentId: string;
  timestamp: number;
  session: BusSession;
  method: 'FACE_ID' | 'NFC' | 'MANUAL';
  confidence?: number;
}

export interface DailyStats {
  totalStudents: number;
  amCount: number;
  pmCount: number;
  missingReturnCount: number;
  systemHealth: {
    accuracy: number;
    frr: number; // False Rejection Rate
    far: number; // False Acceptance Rate
  };
  fleetStatus: {
    running: number;
    idle: number;
    delayed: number;
    breakdown: number;
  }
}

export interface Alert {
  id: string;
  studentId: string;
  type: 'MISSING_RETURN' | 'UNEXPECTED_BOARDING' | 'SYSTEM_ERROR' | 'OVERSPEED' | 'ROUTE_DEVIATION' | 'WRONG_STOP' | 'EMERGENCY';
  message: string;
  severity: 'CRITICAL' | 'WARNING' | 'INFO';
  timestamp: number;
  detectionMethod?: string;
  busId?: string;
}

export type UserRole = 'STUDENT' | 'DRIVER' | 'TEACHER' | 'PARENT';

export interface User {
  id: string;
  name: string;
  role: UserRole;
  email: string;
  avatar?: string;
  linkedStudentId?: string; // For parents
  assignedBusId?: string; // For drivers
}

export type BusStatus = 'RUNNING' | 'IDLE' | 'DELAYED' | 'BREAKDOWN';

export interface GeoCoordinate {
  lat: number;
  lng: number;
}

export interface Bus {
  id: string;
  plateNumber: string;
  driverName: string;
  status: BusStatus;
  location: GeoCoordinate;
  speed: number; // km/h
  nextStop: string;
  eta: string;
  occupancy: number;
  capacity: number;
  routeId: string;
}

export type AppView = 'DASHBOARD' | 'TRACKING' | 'STUDENTS' | 'FLEET' | 'REPORTS' | 'SETTINGS';

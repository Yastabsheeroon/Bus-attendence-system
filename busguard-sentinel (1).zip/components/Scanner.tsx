import React, { useState } from 'react';
import { BusSession, Student } from '../types';
import { MOCK_STUDENTS } from '../constants';

interface ScannerProps {
  currentSession: BusSession;
  onScan: (studentId: string, session: BusSession) => void;
  scannedIds: Set<string>;
}

export const Scanner: React.FC<ScannerProps> = ({ currentSession, onScan, scannedIds }) => {
  const [isScanning, setIsScanning] = useState(false);
  const [lastScanned, setLastScanned] = useState<Student | null>(null);
  const [feedbackMsg, setFeedbackMsg] = useState<string | null>(null);

  // Filter students who haven't been scanned for this session yet to simulate "Next student coming up"
  const pendingStudents = MOCK_STUDENTS.filter(s => !scannedIds.has(s.id));

  const handleSimulateScan = () => {
    if (pendingStudents.length === 0) {
      setFeedbackMsg("All students accounted for in this session.");
      return;
    }

    setIsScanning(true);
    setFeedbackMsg(null);
    setLastScanned(null);

    // Simulate network/processing delay
    setTimeout(() => {
      // Pick a random pending student
      const randomIndex = Math.floor(Math.random() * pendingStudents.length);
      const student = pendingStudents[randomIndex];
      
      onScan(student.id, currentSession);
      setLastScanned(student);
      setIsScanning(false);
    }, 800);
  };

  return (
    <div className="bg-slate-800 rounded-xl p-6 shadow-lg border border-slate-700 h-full flex flex-col items-center justify-center relative overflow-hidden group">
      {/* Pink Gradient Line */}
      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-pink-500 to-white"></div>
      
      <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6 text-pink-500">
          <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 4.875c0-.621.504-1.125 1.125-1.125h4.5c.621 0 1.125.504 1.125 1.125v4.5c0 .621-.504 1.125-1.125 1.125h-4.5A1.125 1.125 0 013.75 9.375v-4.5zM3.75 14.625c0-.621.504-1.125 1.125-1.125h4.5c.621 0 1.125.504 1.125 1.125v4.5c0 .621-.504 1.125-1.125 1.125h-4.5a1.125 1.125 0 01-1.125-1.125v-4.5zM13.5 4.875c0-.621.504-1.125 1.125-1.125h4.5c.621 0 1.125.504 1.125 1.125v4.5c0 .621-.504 1.125-1.125 1.125h-4.5A1.125 1.125 0 0113.5 9.375v-4.5z" />
          <path strokeLinecap="round" strokeLinejoin="round" d="M6.75 6.75h.75v.75h-.75v-.75zM6.75 16.5h.75v.75h-.75v-.75zM16.5 6.75h.75v.75h-.75v-.75zM13.5 13.5h.75v.75h-.75v-.75zM13.5 19.5h.75v.75h-.75v-.75zM19.5 13.5h.75v.75h-.75v-.75zM19.5 19.5h.75v.75h-.75v-.75zM16.5 16.5h.75v.75h-.75v-.75z" />
        </svg>
        Biometric Scanner Sim
      </h2>

      <div className="relative w-48 h-48 mb-8 flex items-center justify-center">
         {/* Scanning Animation Ring */}
         {isScanning && (
           <div className="absolute inset-0 rounded-full border-4 border-pink-500/30 animate-ping"></div>
         )}
         <div className={`w-full h-full rounded-full border-4 flex items-center justify-center bg-slate-900 transition-colors duration-500 overflow-hidden ${isScanning ? 'border-pink-400' : 'border-slate-600 group-hover:border-pink-500/50'}`}>
            {lastScanned ? (
              <img 
                key={lastScanned.id}
                src={lastScanned.avatar} 
                alt="Scanned" 
                className="w-full h-full object-cover animate-fade-in" 
              />
            ) : (
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-20 h-20 text-slate-500 group-hover:text-pink-500/50 transition-colors">
                <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM4.501 20.118a7.5 7.5 0 0114.998 0A17.933 17.933 0 0112 21.75c-2.676 0-5.216-.584-7.499-1.632z" />
              </svg>
            )}
         </div>
      </div>

      <div className="text-center mb-6 min-h-[5rem] flex flex-col justify-center">
        {isScanning ? (
          <p className="text-pink-400 animate-pulse font-mono text-lg">Identifying...</p>
        ) : lastScanned ? (
          <div key={lastScanned.id} className="animate-fade-in-up space-y-1">
             <h3 className="text-2xl font-bold text-white tracking-tight">{lastScanned.name}</h3>
             <div className="flex items-center justify-center gap-2 text-slate-400 text-sm font-medium">
                <span className="bg-slate-700/50 px-2 py-0.5 rounded text-pink-200">{lastScanned.id}</span>
                <span>•</span>
                <span>Grade {lastScanned.grade}</span>
             </div>
             <div className="pt-2">
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-pink-500/10 text-pink-400 text-xs font-bold border border-pink-500/20 uppercase tracking-wider">
                  <span className="w-1.5 h-1.5 rounded-full bg-pink-400 animate-pulse"></span>
                  Verified
                </span>
             </div>
          </div>
        ) : (
          <p className="text-slate-500 font-mono text-sm">{feedbackMsg || "Ready to scan next student"}</p>
        )}
      </div>

      <button
        onClick={handleSimulateScan}
        disabled={isScanning || pendingStudents.length === 0}
        className={`w-full py-4 rounded-lg font-bold text-lg transition-all transform active:scale-95 shadow-lg ${
          pendingStudents.length === 0 
            ? 'bg-slate-700 text-slate-500 cursor-not-allowed'
            : 'bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-500 hover:to-rose-500 text-white shadow-pink-900/30 hover:shadow-pink-500/40'
        }`}
      >
        {isScanning ? 'Processing...' : `Simulate ${currentSession === BusSession.MORNING ? 'AM' : 'PM'} Scan`}
      </button>
      
      <p className="mt-4 text-xs text-slate-500">
        Queued: {pendingStudents.length} students
      </p>
    </div>
  );
};
import React, { useState } from 'react';
import { BusSession, Student } from '../types';
import { MOCK_STUDENTS } from '../constants';

interface BusDriverViewProps {
    session: BusSession;
    onToggleSession: (s: BusSession) => void;
    busId: string;
}

export const BusDriverView: React.FC<BusDriverViewProps> = ({ session, onToggleSession, busId }) => {
  const [emergencyTriggered, setEmergencyTriggered] = useState(false);
  const myStudents = MOCK_STUDENTS.filter(s => s.busId === busId);
  const [markedPresent, setMarkedPresent] = useState<Set<string>>(new Set());

  const handleMark = (id: string) => {
    setMarkedPresent(prev => {
        const next = new Set(prev);
        if (next.has(id)) next.delete(id);
        else next.add(id);
        return next;
    });
  };

  const toggleEmergency = () => {
      setEmergencyTriggered(!emergencyTriggered);
      if (!emergencyTriggered) {
          // Play loud sound effect logic here
          alert("SOS SENT: Emergency signal broadcasted to HQ and Parents!");
      }
  };

  return (
    <div className="max-w-md mx-auto h-full flex flex-col bg-slate-900 min-h-screen pb-20">
      {/* Driver Header */}
      <div className="bg-slate-800 p-4 border-b border-slate-700 sticky top-0 z-30 shadow-lg">
          <div className="flex justify-between items-center mb-4">
              <h1 className="text-xl font-bold text-white flex items-center gap-2">
                  <span className="text-2xl">🚌</span> Bus {busId}
              </h1>
              <div className="flex bg-slate-700 rounded-lg p-1">
                  <button 
                    onClick={() => onToggleSession(BusSession.MORNING)}
                    className={`px-3 py-1 text-xs font-bold rounded ${session === BusSession.MORNING ? 'bg-pink-600 text-white' : 'text-slate-400'}`}
                  >
                      AM
                  </button>
                  <button 
                    onClick={() => onToggleSession(BusSession.AFTERNOON)}
                    className={`px-3 py-1 text-xs font-bold rounded ${session === BusSession.AFTERNOON ? 'bg-pink-600 text-white' : 'text-slate-400'}`}
                  >
                      PM
                  </button>
              </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
               <div className="bg-slate-900 p-2 rounded border border-slate-600">
                   <span className="text-xs text-slate-500 block">Next Stop</span>
                   <span className="font-bold text-white">Maple Ave</span>
               </div>
               <div className="bg-slate-900 p-2 rounded border border-slate-600">
                   <span className="text-xs text-slate-500 block">Load</span>
                   <span className="font-bold text-white">{markedPresent.size} / {myStudents.length}</span>
               </div>
          </div>
      </div>

      {/* Student Manifest */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
          <h2 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-2">Trip Manifest</h2>
          {myStudents.map(student => (
              <div key={student.id} className="bg-slate-800 p-3 rounded-xl border border-slate-700 flex items-center justify-between shadow-sm">
                  <div className="flex items-center gap-3">
                      <img src={student.avatar} alt={student.name} className="w-10 h-10 rounded-full object-cover" />
                      <div>
                          <p className="font-bold text-white">{student.name}</p>
                          <p className="text-xs text-slate-400">Stop: {student.stopName}</p>
                      </div>
                  </div>
                  <button 
                    onClick={() => handleMark(student.id)}
                    className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${
                        markedPresent.has(student.id) 
                        ? 'bg-green-500 text-white shadow-lg shadow-green-500/30 scale-105' 
                        : 'bg-slate-700 text-slate-500 hover:bg-slate-600'
                    }`}
                  >
                      {markedPresent.has(student.id) ? (
                          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={3} stroke="currentColor" className="w-5 h-5">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l6 6 9-13.5" />
                          </svg>
                      ) : (
                          <span className="text-lg font-bold">+</span>
                      )}
                  </button>
              </div>
          ))}
          {myStudents.length === 0 && <div className="text-center text-slate-500 py-10">No students assigned.</div>}
      </div>

      {/* Emergency Footer */}
      <div className="p-4 bg-slate-800 border-t border-slate-700">
          <button 
            onClick={toggleEmergency}
            className={`w-full py-4 rounded-xl font-bold text-lg uppercase tracking-wider shadow-lg transition-all ${
                emergencyTriggered 
                ? 'bg-red-600 animate-pulse text-white shadow-red-900/50' 
                : 'bg-slate-700 text-slate-300 hover:bg-red-500/20 hover:text-red-400 hover:border-red-500 border border-transparent'
            }`}
          >
              {emergencyTriggered ? 'SOS BROADCASTING...' : 'Emergency / Panic Button'}
          </button>
      </div>
    </div>
  );
};

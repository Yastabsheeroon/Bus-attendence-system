import React from 'react';
import { Bus } from '../types';

interface LiveTrackingProps {
  buses: Bus[];
}

export const LiveTracking: React.FC<LiveTrackingProps> = ({ buses }) => {
  return (
    <div className="h-full flex flex-col space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-white flex items-center gap-2">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-8 h-8 text-pink-500">
              <path strokeLinecap="round" strokeLinejoin="round" d="M9 6.75V15m6-6v8.25m.503 3.498l4.875-2.437c.381-.19.622-.58.622-1.006V4.82c0-.836-.88-1.38-1.628-1.006l-3.869 1.934c-.317.159-.69.159-1.006 0L9.503 3.252a1.125 1.125 0 00-1.006 0L3.622 5.689C3.24 5.88 3 6.27 3 6.695V19.18c0 .836.88 1.38 1.628 1.006l3.869-1.934c.317-.159.69-.159 1.006 0l4.994 2.497c.317.158.69.158 1.006 0z" />
            </svg>
            Live Fleet Tracking
        </h2>
        <div className="flex gap-2">
            <span className="px-3 py-1 bg-green-500/10 text-green-400 text-xs rounded-full border border-green-500/30 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></span> GPS Active
            </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-full min-h-[500px]">
        {/* Map Area (Simulated) */}
        <div className="lg:col-span-2 bg-slate-800 rounded-xl border border-slate-700 relative overflow-hidden group">
            <div className="absolute inset-0 bg-slate-900 opacity-50 pointer-events-none"></div>
            {/* Styled "Map" Background using Grid */}
            <div className="absolute inset-0" style={{ 
                backgroundImage: 'linear-gradient(#1e293b 1px, transparent 1px), linear-gradient(90deg, #1e293b 1px, transparent 1px)',
                backgroundSize: '40px 40px',
                opacity: 0.2
            }}></div>
            
            {/* Roads Simulation */}
            <svg className="absolute inset-0 w-full h-full pointer-events-none opacity-20" stroke="currentColor">
               <path d="M100,100 Q400,50 600,300 T900,100" strokeWidth="12" stroke="#475569" fill="none" />
               <path d="M50,400 Q300,500 500,200 T800,500" strokeWidth="12" stroke="#475569" fill="none" />
               <path d="M200,0 V600" strokeWidth="8" stroke="#334155" fill="none" />
               <path d="M600,0 V600" strokeWidth="8" stroke="#334155" fill="none" />
            </svg>

            {/* School Geo-fence */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-32 h-32 border-2 border-pink-500/30 rounded-full bg-pink-500/5 flex items-center justify-center animate-pulse">
                <div className="text-pink-500 text-[10px] font-bold uppercase mt-8">School Zone</div>
            </div>
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-8 h-8 text-white fill-slate-800">
                   <path strokeLinecap="round" strokeLinejoin="round" d="M4.26 10.147a60.436 60.436 0 00-.491 6.347A48.627 48.627 0 0112 20.904a48.627 48.627 0 018.232-4.41 60.46 60.46 0 00-.491-6.347m-15.482 0a50.57 50.57 0 00-2.658-.813A59.905 59.905 0 0112 3.493a59.902 59.902 0 0110.499 5.212 50.556 50.556 0 01-2.658.814m-15.482 0A50.697 50.697 0 0112 13.489a50.702 50.702 0 017.74-3.342M6.75 15a.75.75 0 100-1.5.75.75 0 000 1.5zm0 0v-3.675A55.378 55.378 0 0112 8.443m-7.007 11.55A5.981 5.981 0 006.75 15.75v-1.5" />
                </svg>
            </div>

            {/* Buses */}
            {buses.map((bus, idx) => (
                <div 
                    key={bus.id}
                    className="absolute transition-all duration-1000 ease-linear flex flex-col items-center group/bus cursor-pointer"
                    style={{ 
                        // Mock movement logic based on simple offsets for demo
                        top: `${40 + (idx * 20) + (Math.sin(Date.now() / 1000 + idx) * 5)}%`, 
                        left: `${20 + (idx * 25) + (Math.cos(Date.now() / 1000 + idx) * 5)}%` 
                    }}
                >
                    <div className={`p-2 rounded-lg shadow-lg relative transform transition-transform group-hover/bus:scale-110 ${
                        bus.status === 'RUNNING' ? 'bg-green-500 text-white' :
                        bus.status === 'DELAYED' ? 'bg-amber-500 text-white' :
                        bus.status === 'BREAKDOWN' ? 'bg-red-500 text-white animate-bounce' : 'bg-slate-500 text-white'
                    }`}>
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-5 h-5">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 18.75a1.5 1.5 0 01-3 0m3 0a1.5 1.5 0 00-3 0m3 0h6m-9 0H3.375a1.125 1.125 0 01-1.125-1.125V14.25m17.25 4.5a1.5 1.5 0 01-3 0m3 0a1.5 1.5 0 00-3 0m3 0h1.125c.621 0 1.129-.504 1.09-1.124a17.902 17.902 0 00-3.213-9.193 2.056 2.056 0 00-1.58-.86H14.25M16.5 18.75h-2.25m0-11.177v-.958c0-.568-.422-1.048-.987-1.106a48.554 48.554 0 00-10.026 0 1.106 1.106 0 00-.987 1.106v7.635m12-6.677v6.677m0 4.5v-4.5m0 0h-12" />
                        </svg>
                        {/* Speed Bubble */}
                        <div className="absolute -top-6 left-1/2 -translate-x-1/2 bg-white text-slate-900 text-[10px] font-bold px-1.5 py-0.5 rounded shadow-sm opacity-0 group-hover/bus:opacity-100 transition-opacity whitespace-nowrap">
                            {bus.speed} km/h
                        </div>
                    </div>
                    <span className="mt-1 text-xs font-bold text-white bg-slate-900/80 px-1 rounded">{bus.id}</span>
                </div>
            ))}
        </div>

        {/* Fleet List Side Panel */}
        <div className="bg-slate-800 rounded-xl border border-slate-700 p-4 overflow-y-auto custom-scrollbar">
            <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-4">Active Fleet</h3>
            <div className="space-y-3">
                {buses.map(bus => (
                    <div key={bus.id} className="bg-slate-700/30 p-3 rounded-lg border border-slate-600 hover:border-pink-500/30 transition-colors">
                        <div className="flex justify-between items-start mb-2">
                            <div>
                                <h4 className="font-bold text-white">{bus.id} <span className="text-slate-400 font-normal text-xs">({bus.plateNumber})</span></h4>
                                <p className="text-xs text-slate-400">Driver: {bus.driverName}</p>
                            </div>
                            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                                bus.status === 'RUNNING' ? 'bg-green-500/20 text-green-400' :
                                bus.status === 'DELAYED' ? 'bg-amber-500/20 text-amber-400' :
                                bus.status === 'BREAKDOWN' ? 'bg-red-500/20 text-red-400' : 'bg-slate-500/20 text-slate-400'
                            }`}>
                                {bus.status}
                            </span>
                        </div>
                        <div className="grid grid-cols-2 gap-2 text-xs">
                            <div className="bg-slate-800/50 p-2 rounded">
                                <span className="block text-slate-500 mb-0.5">Speed</span>
                                <span className="font-mono text-white">{bus.speed} km/h</span>
                            </div>
                            <div className="bg-slate-800/50 p-2 rounded">
                                <span className="block text-slate-500 mb-0.5">Next Stop</span>
                                <span className="text-white truncate">{bus.nextStop}</span>
                            </div>
                            <div className="bg-slate-800/50 p-2 rounded">
                                <span className="block text-slate-500 mb-0.5">ETA</span>
                                <span className="font-mono text-pink-400">{bus.eta}</span>
                            </div>
                             <div className="bg-slate-800/50 p-2 rounded">
                                <span className="block text-slate-500 mb-0.5">Load</span>
                                <span className="font-mono text-white">{bus.occupancy}/{bus.capacity}</span>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
      </div>
    </div>
  );
};

import React from 'react';
import { MOCK_STUDENTS, MOCK_BUSES } from '../constants';
import { BusSession } from '../types';

interface ParentViewProps {
    linkedStudentId?: string;
}

export const ParentView: React.FC<ParentViewProps> = ({ linkedStudentId }) => {
  const student = MOCK_STUDENTS.find(s => s.id === linkedStudentId) || MOCK_STUDENTS[0];
  const bus = MOCK_BUSES.find(b => b.id === student.busId);

  return (
    <div className="max-w-md mx-auto h-full flex flex-col bg-slate-900 min-h-screen">
       <div className="bg-slate-800 p-6 rounded-b-3xl shadow-xl border-b border-pink-500/20 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-pink-500/10 rounded-full -mr-10 -mt-10 blur-xl"></div>
            
            <div className="flex items-center gap-4 relative z-10">
                <div className="relative">
                    <img src={student.avatar} alt="Child" className="w-16 h-16 rounded-full border-2 border-white shadow-lg" />
                    <div className="absolute bottom-0 right-0 w-5 h-5 bg-green-500 border-2 border-slate-800 rounded-full"></div>
                </div>
                <div>
                    <h1 className="text-xl font-bold text-white">{student.name}</h1>
                    <p className="text-pink-400 text-sm font-medium">On Board - Return Trip</p>
                </div>
            </div>

            <div className="grid grid-cols-2 gap-3 mt-6 relative z-10">
                <div className="bg-slate-900/60 p-3 rounded-xl backdrop-blur-sm border border-white/5">
                    <span className="text-[10px] text-slate-400 uppercase tracking-wider block mb-1">Bus Number</span>
                    <span className="text-lg font-bold text-white">{bus?.id}</span>
                </div>
                <div className="bg-slate-900/60 p-3 rounded-xl backdrop-blur-sm border border-white/5">
                    <span className="text-[10px] text-slate-400 uppercase tracking-wider block mb-1">ETA Home</span>
                    <span className="text-lg font-bold text-green-400">12 min</span>
                </div>
            </div>
       </div>

       <div className="p-4 space-y-6">
           {/* Live Map Card */}
           <div className="bg-slate-800 rounded-2xl overflow-hidden border border-slate-700 shadow-lg">
                <div className="bg-slate-700/50 p-3 border-b border-slate-700 flex justify-between items-center">
                    <h3 className="font-bold text-slate-200 text-sm flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></span>
                        Live Location
                    </h3>
                    <span className="text-xs text-slate-500">Updated 5s ago</span>
                </div>
                <div className="h-48 bg-slate-900 relative">
                    {/* Fake Map */}
                    <div className="absolute inset-0 opacity-20" style={{ 
                        backgroundImage: 'radial-gradient(circle, #334155 1px, transparent 1px)',
                        backgroundSize: '20px 20px'
                    }}></div>
                    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-1 bg-slate-700"></div>
                    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-1 h-full bg-slate-700"></div>
                    
                    {/* Bus Icon */}
                    <div className="absolute top-1/2 left-1/3 -translate-x-1/2 -translate-y-1/2 flex flex-col items-center">
                         <div className="bg-pink-600 p-2 rounded-lg shadow-lg shadow-pink-600/30 animate-bounce">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-5 h-5 text-white">
                                <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 18.75a1.5 1.5 0 01-3 0m3 0a1.5 1.5 0 00-3 0m3 0h6m-9 0H3.375a1.125 1.125 0 01-1.125-1.125V14.25m17.25 4.5a1.5 1.5 0 01-3 0m3 0a1.5 1.5 0 00-3 0m3 0h1.125c.621 0 1.129-.504 1.09-1.124a17.902 17.902 0 00-3.213-9.193 2.056 2.056 0 00-1.58-.86H14.25M16.5 18.75h-2.25m0-11.177v-.958c0-.568-.422-1.048-.987-1.106a48.554 48.554 0 00-10.026 0 1.106 1.106 0 00-.987 1.106v7.635m12-6.677v6.677m0 4.5v-4.5m0 0h-12" />
                            </svg>
                         </div>
                         <div className="mt-1 bg-black/50 text-[10px] px-1.5 rounded text-white font-bold">{bus?.speed} km/h</div>
                    </div>
                </div>
           </div>

           {/* Timeline Log */}
           <div>
               <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-4">Activity Log</h3>
               <div className="space-y-6 pl-2 border-l-2 border-slate-700 ml-2">
                   <div className="relative pl-6">
                       <div className="absolute -left-[9px] top-0 w-4 h-4 rounded-full bg-pink-500 border-2 border-slate-900"></div>
                       <p className="text-white text-sm font-bold">Boarded Return Bus</p>
                       <p className="text-xs text-slate-500">3:30 PM &bull; School Gate 2</p>
                   </div>
                   <div className="relative pl-6 opacity-60">
                       <div className="absolute -left-[9px] top-0 w-4 h-4 rounded-full bg-slate-600 border-2 border-slate-900"></div>
                       <p className="text-white text-sm font-bold">Arrived at School</p>
                       <p className="text-xs text-slate-500">8:15 AM &bull; On Time</p>
                   </div>
                   <div className="relative pl-6 opacity-60">
                       <div className="absolute -left-[9px] top-0 w-4 h-4 rounded-full bg-slate-600 border-2 border-slate-900"></div>
                       <p className="text-white text-sm font-bold">Boarded Morning Bus</p>
                       <p className="text-xs text-slate-500">7:45 AM &bull; Home Stop</p>
                   </div>
               </div>
           </div>
       </div>
    </div>
  );
};

import React, { useMemo, useState, useEffect } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { Alert } from '../types';
import { MOCK_STUDENTS, SYSTEM_METRICS_BASE } from '../constants';
import { generateSafetyReport } from '../services/geminiService';
import Markdown from 'react-markdown';

interface DashboardProps {
  amAttendance: Set<string>;
  pmAttendance: Set<string>;
  alerts: Alert[];
  onGenerateAlert: () => void;
}

// Helper Component for animating numbers on change
const AnimatedCounter = ({ value, colorClass = "text-white" }: { value: number, colorClass?: string }) => {
  const [animate, setAnimate] = useState(false);

  useEffect(() => {
    // Trigger animation when value changes
    setAnimate(true);
    const timeout = setTimeout(() => setAnimate(false), 300);
    return () => clearTimeout(timeout);
  }, [value]);

  return (
    <span className={`transition-all duration-300 inline-block transform ${animate ? 'scale-125 text-white/90' : 'scale-100'} ${colorClass}`}>
      {value}
    </span>
  );
};

export const Dashboard: React.FC<DashboardProps> = ({ 
  amAttendance, 
  pmAttendance, 
  alerts,
  onGenerateAlert 
}) => {
  const [report, setReport] = useState<string | null>(null);
  const [loadingReport, setLoadingReport] = useState(false);
  const [expandedAlertId, setExpandedAlertId] = useState<string | null>(null);

  // Derived Data
  const missingReturnStudents = useMemo(() => {
    return MOCK_STUDENTS.filter(s => amAttendance.has(s.id) && !pmAttendance.has(s.id));
  }, [amAttendance, pmAttendance]);

  const totalStudents = MOCK_STUDENTS.length;
  
  // Fleet Stats Mock for Report Compatibility (Removed visual widget)
  const fleetStats = {
      running: 0,
      idle: 0,
      delayed: 0,
      breakdown: 0,
  };

  // Prepare Chart Data
  const attendanceData = [
    { name: 'Morning', count: amAttendance.size, fill: '#f472b6' }, // pink-400
    { name: 'Return', count: pmAttendance.size, fill: '#ffffff' },  // white
  ];

  const handleGenerateReport = async () => {
    setLoadingReport(true);
    const stats = {
      totalStudents,
      amCount: amAttendance.size,
      pmCount: pmAttendance.size,
      missingReturnCount: missingReturnStudents.length,
      systemHealth: SYSTEM_METRICS_BASE,
      fleetStatus: fleetStats
    };
    
    if (missingReturnStudents.length > 0) {
      onGenerateAlert();
    }

    const text = await generateSafetyReport(stats, missingReturnStudents, alerts);
    setReport(text);
    setLoadingReport(false);
  };

  const toggleAlert = (id: string) => {
    setExpandedAlertId(prev => prev === id ? null : id);
  };

  return (
    <div className="space-y-6 h-full flex flex-col">
      
      {/* Top Metrics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Morning Boarding Card (Live) */}
        <div className="bg-pink-600 p-4 rounded-xl border border-pink-500 shadow-lg shadow-pink-900/20 relative overflow-hidden text-white group">
          <div className="absolute top-0 right-0 w-24 h-24 bg-white/10 rounded-full -mr-8 -mt-8 blur-2xl"></div>
          <div className="flex justify-between items-start relative z-10">
            <p className="text-xs text-pink-100 font-semibold uppercase tracking-wider">Morning Boarding</p>
            <span className="flex h-2 w-2 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-white"></span>
            </span>
          </div>
          <div className="flex items-end gap-2 mt-1 relative z-10">
            <p className="text-3xl font-bold">
               <AnimatedCounter value={amAttendance.size} colorClass="text-white" />
            </p>
            <p className="text-sm font-medium text-pink-200 mb-1.5">
              / {totalStudents} <span className="text-xs opacity-75">({Math.round((amAttendance.size / totalStudents) * 100)}%)</span>
            </p>
          </div>
          <div className="relative z-10 mt-3 h-1.5 w-full bg-black/20 rounded-full overflow-hidden">
             <div 
               className="h-full bg-white transition-all duration-500 ease-out"
               style={{ width: `${(amAttendance.size / totalStudents) * 100}%` }}
             ></div>
          </div>
        </div>

        {/* Return Boarding Card (Live) */}
        <div className="bg-white text-slate-900 p-4 rounded-xl border border-white/50 shadow-lg relative overflow-hidden group">
           <div className="absolute bottom-0 right-0 w-16 h-16 bg-pink-500/10 rounded-full -mr-4 -mb-4"></div>
           <div className="flex justify-between items-start relative z-10">
              <p className="text-xs text-slate-500 font-bold uppercase tracking-wider">Return Boarding</p>
              <span className="flex h-2 w-2 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-pink-500 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-pink-500"></span>
              </span>
           </div>
           <div className="flex items-end gap-2 mt-1 relative z-10">
              <p className="text-3xl font-bold text-pink-600">
                  <AnimatedCounter value={pmAttendance.size} colorClass="text-pink-600" />
              </p>
              <p className="text-sm font-medium text-slate-400 mb-1.5">
                / {totalStudents} <span className="text-xs opacity-75">({Math.round((pmAttendance.size / totalStudents) * 100)}%)</span>
              </p>
           </div>
           <div className="relative z-10 mt-3 h-1.5 w-full bg-slate-200 rounded-full overflow-hidden">
              <div 
                className="h-full bg-pink-500 transition-all duration-500 ease-out"
                style={{ width: `${(pmAttendance.size / totalStudents) * 100}%` }}
              ></div>
           </div>
        </div>
      </div>

      {/* Main Charts & Alerts Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Col: Charts */}
        <div className="lg:col-span-2 space-y-6">
             {/* Attendance Comparison */}
             <div className="bg-slate-800 p-6 rounded-xl border border-slate-700 shadow-lg flex flex-col hover:shadow-pink-900/10 transition-shadow h-80">
                <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                    <span className="w-2 h-6 bg-pink-500 rounded-full"></span>
                    Daily Traffic
                </h3>
                <div className="flex-1 w-full min-h-[200px]">
                    <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={attendanceData} margin={{ top: 20, right: 30, left: 0, bottom: 5 }}>
                        <XAxis dataKey="name" stroke="#cbd5e1" fontSize={12} tickLine={false} axisLine={false} />
                        <YAxis stroke="#cbd5e1" fontSize={12} tickLine={false} axisLine={false} />
                        <Tooltip 
                        cursor={{ fill: 'rgba(236, 72, 153, 0.1)' }}
                        contentStyle={{ backgroundColor: '#1e293b', borderColor: '#ec4899', color: '#f8fafc', borderRadius: '8px' }}
                        />
                        <Bar dataKey="count" radius={[6, 6, 0, 0]}>
                        {attendanceData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.fill} />
                        ))}
                        </Bar>
                    </BarChart>
                    </ResponsiveContainer>
                </div>
            </div>

            {/* Performance KPIs */}
            <div className="grid grid-cols-3 gap-4">
                 <div className="bg-slate-800 p-4 rounded-xl border border-slate-700">
                    <p className="text-xs text-slate-400 uppercase tracking-widest mb-1">On-Time %</p>
                    <p className="text-2xl font-bold text-white">94%</p>
                    <div className="w-full bg-slate-700 h-1 mt-2 rounded-full"><div className="w-[94%] bg-green-500 h-full rounded-full"></div></div>
                 </div>
                 <div className="bg-slate-800 p-4 rounded-xl border border-slate-700">
                    <p className="text-xs text-slate-400 uppercase tracking-widest mb-1">Avg Boarding</p>
                    <p className="text-2xl font-bold text-white">4.2s</p>
                    <p className="text-[10px] text-slate-500">per student</p>
                 </div>
                 <div className="bg-slate-800 p-4 rounded-xl border border-slate-700">
                    <p className="text-xs text-slate-400 uppercase tracking-widest mb-1">Alert Acc.</p>
                    <p className="text-2xl font-bold text-pink-500">99.9%</p>
                 </div>
            </div>
        </div>

        {/* Right Col: Alerts Feed */}
        <div className="bg-slate-800 p-6 rounded-xl border border-slate-700 shadow-lg flex flex-col h-full max-h-[500px]">
            <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
               <div className="p-1.5 bg-amber-500/20 rounded-lg">
                 <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-4 h-4 text-amber-500">
                   <path strokeLinecap="round" strokeLinejoin="round" d="M14.857 17.082a23.848 23.848 0 005.454-1.31A8.967 8.967 0 0118 9.75v-.7V9A6 6 0 006 9v.75a8.967 8.967 0 01-2.312 6.022c1.733.64 3.56 1.085 5.455 1.31m5.714 0a24.255 24.255 0 01-5.714 0m5.714 0a3 3 0 11-5.714 0" />
                 </svg>
               </div>
               Live Alert Feed
            </h3>
            <div className="space-y-3 flex-1 overflow-y-auto custom-scrollbar pr-2">
              {alerts.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full text-slate-500 opacity-60">
                    <p className="text-sm">System Normal</p>
                </div>
              ) : (
                alerts.map((alert) => (
                  <div 
                    key={alert.id} 
                    onClick={() => toggleAlert(alert.id)}
                    className={`p-3 rounded-lg border flex items-start gap-3 transition-all animate-fade-in cursor-pointer hover:brightness-110 active:scale-[0.99] ${
                      alert.severity === 'CRITICAL' ? 'bg-red-500/10 border-red-500/30 text-red-200' :
                      alert.severity === 'WARNING' ? 'bg-amber-500/10 border-amber-500/30 text-amber-200' :
                      'bg-slate-700/50 border-slate-600 text-slate-300'
                    }`}
                  >
                    <div className={`mt-1.5 w-2 h-2 rounded-full shrink-0 ${
                       alert.severity === 'CRITICAL' ? 'bg-red-500 animate-pulse' :
                       alert.severity === 'WARNING' ? 'bg-amber-500' : 'bg-pink-500'
                    }`}></div>
                    <div className="flex-1">
                      <div className="flex justify-between items-start">
                        <span className="font-bold text-sm tracking-wide">{alert.type.replace('_', ' ')}</span>
                        <div className="flex items-center gap-2">
                           <span className="text-xs opacity-60 font-mono">{new Date(alert.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                        </div>
                      </div>
                      <p className="text-sm mt-1 opacity-90 leading-relaxed">{alert.message}</p>
                      
                      {/* Expanded Details */}
                      {expandedAlertId === alert.id && (
                        <div className="mt-3 pt-3 border-t border-white/10 text-xs grid grid-cols-2 gap-2 opacity-80 animate-fade-in">
                            {alert.busId && (
                                <div>
                                    <span className="block text-[10px] uppercase opacity-60 mb-0.5">Bus</span>
                                    <span className="font-mono bg-black/20 px-1 rounded">{alert.busId}</span>
                                </div>
                            )}
                             <div className="col-span-2">
                                <span className="block text-[10px] uppercase opacity-60 mb-0.5">Method</span>
                                {alert.detectionMethod || 'System Automated'}
                            </div>
                        </div>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
        </div>
      </div>

      {/* Gemini AI Report Section */}
      <div className="bg-gradient-to-r from-pink-900/40 to-slate-900 p-6 rounded-xl border border-pink-500/20 shadow-lg">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-bold text-pink-200 flex items-center gap-2">
            AI Safety Executive Summary
          </h3>
          <button
            onClick={handleGenerateReport}
            disabled={loadingReport}
            className="px-5 py-2.5 bg-white text-pink-600 hover:bg-pink-50 rounded-lg text-sm font-bold transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2 shadow-lg shadow-white/10"
          >
            {loadingReport ? 'Generating...' : 'Generate Report'}
          </button>
        </div>
        
        <div className="bg-slate-900/60 p-5 rounded-lg border border-pink-500/10 min-h-[100px] text-slate-300 text-sm leading-relaxed relative">
          {report ? (
             <div className="prose prose-invert prose-sm max-w-none prose-p:text-slate-300 prose-headings:text-pink-200 prose-strong:text-white prose-li:text-slate-300">
               <div className="markdown-body">
                   <Markdown>{report}</Markdown>
               </div>
             </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-4 text-center">
              <p className="text-slate-500 italic mb-2">AI analysis not yet generated</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
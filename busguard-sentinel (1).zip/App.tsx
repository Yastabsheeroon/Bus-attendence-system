import React, { useState } from 'react';
import { Scanner } from './components/Scanner';
import { Dashboard } from './components/Dashboard';
import { Auth } from './components/Auth';
import { BusSession, Alert, Student, UserRole, User } from './types';
import { MOCK_STUDENTS } from './constants';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [currentSession, setCurrentSession] = useState<BusSession>(BusSession.MORNING);
  const [amAttendance, setAmAttendance] = useState<Set<string>>(new Set());
  const [pmAttendance, setPmAttendance] = useState<Set<string>>(new Set());
  const [alerts, setAlerts] = useState<Alert[]>([]);
  
  // Audio for alerts
  const playAlertSound = () => {
    // console.log("Beep! Alert triggered.");
  };

  const handleLogin = (role: UserRole, name: string, avatar?: string) => {
    setUser({
      id: 'u-' + Math.random().toString(36).substr(2, 5),
      name,
      role,
      email: `${name.toLowerCase().replace(' ', '.')}@school.edu`,
      avatar,
    });
  };

  const handleLogout = () => {
    setUser(null);
  };

  const addAlert = (newAlert: Omit<Alert, 'id' | 'timestamp'>) => {
    const alert: Alert = {
      ...newAlert,
      id: Math.random().toString(36).substr(2, 9),
      timestamp: Date.now(),
    };
    setAlerts(prev => [alert, ...prev]);
    if (newAlert.severity === 'CRITICAL' || newAlert.severity === 'WARNING') {
      playAlertSound();
    }
  };

  const handleScan = (studentId: string, session: BusSession) => {
    const student = MOCK_STUDENTS.find(s => s.id === studentId);
    if (!student) return;

    if (session === BusSession.MORNING) {
      if (!amAttendance.has(studentId)) {
        setAmAttendance(prev => new Set(prev).add(studentId));
      }
    } else {
      // Afternoon Logic
      if (!pmAttendance.has(studentId)) {
        setPmAttendance(prev => new Set(prev).add(studentId));
        
        // Check for unexpected boarding (Student who didn't come in the morning)
        if (!amAttendance.has(studentId)) {
          addAlert({
            studentId,
            type: 'UNEXPECTED_BOARDING',
            message: `Warning: ${student.name} boarded return bus but was not present in Morning session.`,
            severity: 'WARNING',
            detectionMethod: 'Biometric Cross-check'
          });
        }
      }
    }
  };

  const handleSessionSwitch = (session: BusSession) => {
    setCurrentSession(session);
  };

  const triggerEndOfDayCheck = () => {
    const missingStudents: Student[] = [];
    
    amAttendance.forEach(id => {
      if (!pmAttendance.has(id)) {
        const student = MOCK_STUDENTS.find(s => s.id === id);
        if (student) {
          missingStudents.push(student);
          // Check if alert already exists to avoid duplicates
          const alreadyAlerted = alerts.some(a => 
            a.type === 'MISSING_RETURN' && a.studentId === id
          );
          
          if (!alreadyAlerted) {
            addAlert({
              studentId: id,
              type: 'MISSING_RETURN',
              message: `CRITICAL: ${student.name} (Grade ${student.grade}) missing from return bus!`,
              severity: 'CRITICAL',
              detectionMethod: 'AI Attendance Audit'
            });
          }
        }
      }
    });

    if (missingStudents.length === 0) {
      addAlert({
        studentId: 'SYSTEM',
        type: 'SYSTEM_ERROR',
        message: 'End of day check complete. All morning students accounted for.',
        severity: 'INFO',
        detectionMethod: 'System Scheduler'
      });
    }
  };

  if (!user) {
    return <Auth onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col font-inter">
        {/* Header */}
        <header className="bg-slate-900/80 backdrop-blur-md border-b border-white/10 shrink-0 sticky top-0 z-50">
            <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
                <div className="flex items-center gap-3">
                    <div className="bg-gradient-to-tr from-pink-500 to-rose-500 p-2 rounded-lg shadow-lg shadow-pink-500/20">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-6 h-6 text-white">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 18.75a1.5 1.5 0 01-3 0m3 0a1.5 1.5 0 00-3 0m3 0h6m-9 0H3.375a1.125 1.125 0 01-1.125-1.125V14.25m17.25 4.5a1.5 1.5 0 01-3 0m3 0a1.5 1.5 0 00-3 0m3 0h1.125c.621 0 1.129-.504 1.09-1.124a17.902 17.902 0 00-3.213-9.193 2.056 2.056 0 00-1.58-.86H14.25M16.5 18.75h-2.25m0-11.177v-.958c0-.568-.422-1.048-.987-1.106a48.554 48.554 0 00-10.026 0 1.106 1.106 0 00-.987 1.106v7.635m12-6.677v6.677m0 4.5v-4.5m0 0h-12" />
                        </svg>
                    </div>
                    <div>
                        <h1 className="text-xl font-bold text-white tracking-tight hidden sm:block">
                            BusGuard <span className="text-pink-500">Sentinel</span>
                        </h1>
                    </div>
                </div>
                
                <div className="flex items-center gap-6">
                    <div className="flex items-center gap-4 bg-slate-800 p-1 rounded-lg border border-slate-700">
                    <button
                        onClick={() => handleSessionSwitch(BusSession.MORNING)}
                        className={`px-4 py-1.5 rounded-md text-sm font-medium transition-all ${
                        currentSession === BusSession.MORNING
                            ? 'bg-pink-600 text-white shadow-lg shadow-pink-900/40'
                            : 'text-slate-400 hover:text-white'
                        }`}
                    >
                        Morning
                    </button>
                    <button
                        onClick={() => handleSessionSwitch(BusSession.AFTERNOON)}
                        className={`px-4 py-1.5 rounded-md text-sm font-medium transition-all ${
                        currentSession === BusSession.AFTERNOON
                            ? 'bg-pink-600 text-white shadow-lg shadow-pink-900/40'
                            : 'text-slate-400 hover:text-white'
                        }`}
                    >
                        Return
                    </button>
                    </div>

                    <div className="h-6 w-px bg-slate-700 hidden sm:block"></div>

                    <div className="flex items-center gap-3">
                    {user.avatar && (
                        <img src={user.avatar} alt="Profile" className="w-9 h-9 rounded-full border border-pink-500/30 object-cover shadow-sm" />
                    )}
                    <div className="text-right hidden sm:block">
                        <p className="text-sm font-bold text-white leading-none">{user.name}</p>
                        <p className="text-xs text-pink-400 font-medium mt-1">{user.role}</p>
                    </div>
                    <button 
                        onClick={handleLogout}
                        className="p-2 hover:bg-slate-800 rounded-full text-slate-400 hover:text-pink-500 transition-colors"
                        title="Logout"
                    >
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-5 h-5">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 9V5.25A2.25 2.25 0 0013.5 3h-6a2.25 2.25 0 00-2.25 2.25v13.5A2.25 2.25 0 007.5 21h6a2.25 2.25 0 002.25-2.25V15M12 9l-3 3m0 0l3 3m-3-3h12.75" />
                        </svg>
                    </button>
                    </div>
                </div>
            </div>
        </header>

        {/* Main Content Area */}
        <main className="flex-1 overflow-auto bg-slate-900/50 p-6">
            <div className="max-w-7xl mx-auto h-full">
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 h-full">
                    {/* Left Column: Scanner (Simulation) */}
                    <div className="lg:col-span-1 space-y-6">
                        <Scanner 
                            currentSession={currentSession}
                            onScan={handleScan}
                            scannedIds={currentSession === BusSession.MORNING ? amAttendance : pmAttendance}
                        />
                        
                        {/* Quick Actions Panel */}
                        <div className="bg-slate-800 rounded-xl p-6 border border-slate-700">
                            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4">Control Center</h3>
                            <button 
                                onClick={triggerEndOfDayCheck}
                                className="w-full flex items-center justify-between p-3 rounded-lg bg-pink-500/10 border border-pink-500/30 text-pink-300 hover:bg-pink-500/20 transition-all group"
                            >
                                <span className="font-medium">Force End-of-Day Check</span>
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5 group-hover:translate-x-1 transition-transform">
                                <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m9-.75a9 9 0 11-18 0 9 9 0 0118 0zm-9 3.75h.008v.008H12v-.008z" />
                                </svg>
                            </button>
                        </div>
                    </div>

                    {/* Right Column: Dashboard */}
                    <div className="lg:col-span-2">
                        <Dashboard 
                            amAttendance={amAttendance}
                            pmAttendance={pmAttendance}
                            alerts={alerts}
                            onGenerateAlert={triggerEndOfDayCheck}
                        />
                    </div>
                </div>
            </div>
        </main>
    </div>
  );
}